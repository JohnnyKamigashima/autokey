time.sleep(3)  # espera por 300 milissegundos
keyboard.send_keys("<enter>") # pressiona enter
time.sleep(1)  # espera por 300 milissegundos
keyboard.send_keys("<tab>") # pressiona tab
time.sleep(0.1)  # espera por 300 milissegundos
keyboard.send_keys("<tab>") # pressiona tab
time.sleep(0.1)  # espera por 300 milissegundos
keyboard.send_keys("<tab>") # pressiona tab
time.sleep(0.5)  # espera por 300 milissegundos
keyboard.send_keys(" ") # pressiona space
