# Enter script code
keyboard.send_keys("100") # pressiona tab
keyboard.send_keys("<tab>") # pressiona tab
keyboard.send_keys("250") # pressiona tab
keyboard.send_keys("<tab>") # pressiona tab
keyboard.send_keys("500") # pressiona tab
keyboard.send_keys("<tab>") # pressiona tab
keyboard.send_keys("50") # pressiona tab
#keyboard.send_keys("<tab>") # pressiona tab
#keyboard.send_keys("20") # pressiona tab

#keyboard.send_keys("<tab>") # pressiona tab
#keyboard.send_keys("500") # pressiona tab
#keyboard.send_keys("<tab>") # pressiona tab
#keyboard.send_keys("<tab>") # pressiona tab
